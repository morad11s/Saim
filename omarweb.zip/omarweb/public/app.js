let token = localStorage.getItem('admin_token');
let contentData = {};
let currentSection = 'home';
let currentFontId = null;
let _pickerTarget = null;

/* ── 100 SOCIAL ICONS MAP ── */
const socialIcons = {
  instagram:       '<i class="fa-brands fa-instagram"></i>',
  twitter:         '<i class="fa-brands fa-x-twitter"></i>',
  'x-twitter':     '<i class="fa-brands fa-x-twitter"></i>',
  x:               '<i class="fa-brands fa-x-twitter"></i>',
  facebook:        '<i class="fa-brands fa-facebook"></i>',
  linkedin:        '<i class="fa-brands fa-linkedin"></i>',
  youtube:         '<i class="fa-brands fa-youtube"></i>',
  tiktok:          '<i class="fa-brands fa-tiktok"></i>',
  snapchat:        '<i class="fa-brands fa-snapchat"></i>',
  telegram:        '<i class="fa-brands fa-telegram"></i>',
  whatsapp:        '<i class="fa-brands fa-whatsapp"></i>',
  pinterest:       '<i class="fa-brands fa-pinterest"></i>',
  reddit:          '<i class="fa-brands fa-reddit"></i>',
  discord:         '<i class="fa-brands fa-discord"></i>',
  twitch:          '<i class="fa-brands fa-twitch"></i>',
  spotify:         '<i class="fa-brands fa-spotify"></i>',
  soundcloud:      '<i class="fa-brands fa-soundcloud"></i>',
  medium:          '<i class="fa-brands fa-medium"></i>',
  tumblr:          '<i class="fa-brands fa-tumblr"></i>',
  flickr:          '<i class="fa-brands fa-flickr"></i>',
  vimeo:           '<i class="fa-brands fa-vimeo"></i>',
  dribbble:        '<i class="fa-brands fa-dribbble"></i>',
  behance:         '<i class="fa-brands fa-behance"></i>',
  deviantart:      '<i class="fa-brands fa-deviantart"></i>',
  figma:           '<i class="fa-brands fa-figma"></i>',
  github:          '<i class="fa-brands fa-github"></i>',
  gitlab:          '<i class="fa-brands fa-gitlab"></i>',
  bitbucket:       '<i class="fa-brands fa-bitbucket"></i>',
  'stack-overflow':'<i class="fa-brands fa-stack-overflow"></i>',
  codepen:         '<i class="fa-brands fa-codepen"></i>',
  npm:             '<i class="fa-brands fa-npm"></i>',
  docker:          '<i class="fa-brands fa-docker"></i>',
  aws:             '<i class="fa-brands fa-aws"></i>',
  react:           '<i class="fa-brands fa-react"></i>',
  angular:         '<i class="fa-brands fa-angular"></i>',
  vuejs:           '<i class="fa-brands fa-vuejs"></i>',
  'node-js':       '<i class="fa-brands fa-node-js"></i>',
  python:          '<i class="fa-brands fa-python"></i>',
  java:            '<i class="fa-brands fa-java"></i>',
  php:             '<i class="fa-brands fa-php"></i>',
  html5:           '<i class="fa-brands fa-html5"></i>',
  css3:            '<i class="fa-brands fa-css3"></i>',
  js:              '<i class="fa-brands fa-js"></i>',
  bootstrap:       '<i class="fa-brands fa-bootstrap"></i>',
  sass:            '<i class="fa-brands fa-sass"></i>',
  yarn:            '<i class="fa-brands fa-yarn"></i>',
  etsy:            '<i class="fa-brands fa-etsy"></i>',
  paypal:          '<i class="fa-brands fa-paypal"></i>',
  patreon:         '<i class="fa-brands fa-patreon"></i>',
  slack:           '<i class="fa-brands fa-slack"></i>',
  skype:           '<i class="fa-brands fa-skype"></i>',
  apple:           '<i class="fa-brands fa-apple"></i>',
  google:          '<i class="fa-brands fa-google"></i>',
  android:         '<i class="fa-brands fa-android"></i>',
  microsoft:       '<i class="fa-brands fa-microsoft"></i>',
  windows:         '<i class="fa-brands fa-windows"></i>',
  amazon:          '<i class="fa-brands fa-amazon"></i>',
  shopify:         '<i class="fa-brands fa-shopify"></i>',
  wordpress:       '<i class="fa-brands fa-wordpress"></i>',
  'google-drive':  '<i class="fa-brands fa-google-drive"></i>',
  dropbox:         '<i class="fa-brands fa-dropbox"></i>',
  steam:           '<i class="fa-brands fa-steam"></i>',
  playstation:     '<i class="fa-brands fa-playstation"></i>',
  xbox:            '<i class="fa-brands fa-xbox"></i>',
  'itch-io':       '<i class="fa-brands fa-itch-io"></i>',
  vk:              '<i class="fa-brands fa-vk"></i>',
  weibo:           '<i class="fa-brands fa-weibo"></i>',
  qq:              '<i class="fa-brands fa-qq"></i>',
  line:            '<i class="fa-brands fa-line"></i>',
  xing:            '<i class="fa-brands fa-xing"></i>',
  'product-hunt':  '<i class="fa-brands fa-product-hunt"></i>',
  'hacker-news':   '<i class="fa-brands fa-hacker-news"></i>',
  'y-combinator':  '<i class="fa-brands fa-y-combinator"></i>',
  angellist:       '<i class="fa-brands fa-angellist"></i>',
  foursquare:      '<i class="fa-brands fa-foursquare"></i>',
  yelp:            '<i class="fa-brands fa-yelp"></i>',
  airbnb:          '<i class="fa-brands fa-airbnb"></i>',
  uber:            '<i class="fa-brands fa-uber"></i>',
  lyft:            '<i class="fa-brands fa-lyft"></i>',
  stripe:          '<i class="fa-brands fa-stripe"></i>',
  bitcoin:         '<i class="fa-brands fa-bitcoin"></i>',
  ethereum:        '<i class="fa-brands fa-ethereum"></i>',
  kickstarter:     '<i class="fa-brands fa-kickstarter"></i>',
  jira:            '<i class="fa-brands fa-jira"></i>',
  trello:          '<i class="fa-brands fa-trello"></i>',
  atlassian:       '<i class="fa-brands fa-atlassian"></i>',
  lastfm:          '<i class="fa-brands fa-lastfm"></i>',
  bandcamp:        '<i class="fa-brands fa-bandcamp"></i>',
  deezer:          '<i class="fa-brands fa-deezer"></i>',
  'app-store':     '<i class="fa-brands fa-app-store"></i>',
  'google-play':   '<i class="fa-brands fa-google-play"></i>',
  'font-awesome':  '<i class="fa-brands fa-font-awesome"></i>',
  'creative-commons':'<i class="fa-brands fa-creative-commons"></i>',
  link:            '<i class="fa-solid fa-link"></i>',
  envelope:        '<i class="fa-solid fa-envelope"></i>',
  globe:           '<i class="fa-solid fa-globe"></i>',
  phone:           '<i class="fa-solid fa-phone"></i>',
  'location-dot':  '<i class="fa-solid fa-location-dot"></i>',
  'share-nodes':   '<i class="fa-solid fa-share-nodes"></i>',
  store:           '<i class="fa-solid fa-store"></i>',
  briefcase:       '<i class="fa-solid fa-briefcase"></i>',
  video:           '<i class="fa-solid fa-video"></i>',
  image:           '<i class="fa-solid fa-image"></i>',
  music:           '<i class="fa-solid fa-music"></i>',
  star:            '<i class="fa-solid fa-star"></i>',
  heart:           '<i class="fa-solid fa-heart"></i>',
  camera:          '<i class="fa-solid fa-camera"></i>',
  pencil:          '<i class="fa-solid fa-pencil"></i>',
  code:            '<i class="fa-solid fa-code"></i>',
  laptop:          '<i class="fa-solid fa-laptop"></i>',
  default:         '<i class="fa-solid fa-link"></i>'
};

/* ── ICON LIBRARY for picker ── */
const iconLibrary = [
  {n:'Instagram',i:'instagram'},{n:'X / Twitter',i:'x-twitter'},{n:'Facebook',i:'facebook'},
  {n:'LinkedIn',i:'linkedin'},{n:'YouTube',i:'youtube'},{n:'TikTok',i:'tiktok'},
  {n:'Snapchat',i:'snapchat'},{n:'Telegram',i:'telegram'},{n:'WhatsApp',i:'whatsapp'},
  {n:'Pinterest',i:'pinterest'},{n:'Reddit',i:'reddit'},{n:'Discord',i:'discord'},
  {n:'Twitch',i:'twitch'},{n:'Spotify',i:'spotify'},{n:'SoundCloud',i:'soundcloud'},
  {n:'Medium',i:'medium'},{n:'Tumblr',i:'tumblr'},{n:'Flickr',i:'flickr'},
  {n:'Vimeo',i:'vimeo'},{n:'Dribbble',i:'dribbble'},{n:'Behance',i:'behance'},
  {n:'DeviantArt',i:'deviantart'},{n:'Figma',i:'figma'},
  {n:'GitHub',i:'github'},{n:'GitLab',i:'gitlab'},{n:'Bitbucket',i:'bitbucket'},
  {n:'Stack Overflow',i:'stack-overflow'},{n:'CodePen',i:'codepen'},
  {n:'npm',i:'npm'},{n:'Docker',i:'docker'},{n:'AWS',i:'aws'},
  {n:'React',i:'react'},{n:'Angular',i:'angular'},{n:'Vue.js',i:'vuejs'},
  {n:'Node.js',i:'node-js'},{n:'Python',i:'python'},{n:'Java',i:'java'},
  {n:'PHP',i:'php'},{n:'HTML5',i:'html5'},{n:'CSS3',i:'css3'},
  {n:'JavaScript',i:'js'},{n:'Bootstrap',i:'bootstrap'},{n:'Sass',i:'sass'},
  {n:'Yarn',i:'yarn'},{n:'Etsy',i:'etsy'},{n:'PayPal',i:'paypal'},
  {n:'Patreon',i:'patreon'},{n:'Slack',i:'slack'},{n:'Skype',i:'skype'},
  {n:'Apple',i:'apple'},{n:'Google',i:'google'},{n:'Android',i:'android'},
  {n:'Microsoft',i:'microsoft'},{n:'Windows',i:'windows'},{n:'Amazon',i:'amazon'},
  {n:'Shopify',i:'shopify'},{n:'WordPress',i:'wordpress'},
  {n:'Google Drive',i:'google-drive'},{n:'Dropbox',i:'dropbox'},
  {n:'Steam',i:'steam'},{n:'PlayStation',i:'playstation'},{n:'Xbox',i:'xbox'},
  {n:'Itch.io',i:'itch-io'},{n:'VK',i:'vk'},{n:'Weibo',i:'weibo'},
  {n:'QQ',i:'qq'},{n:'Line',i:'line'},{n:'Xing',i:'xing'},
  {n:'Product Hunt',i:'product-hunt'},{n:'Hacker News',i:'hacker-news'},
  {n:'Y Combinator',i:'y-combinator'},{n:'AngelList',i:'angellist'},
  {n:'Foursquare',i:'foursquare'},{n:'Yelp',i:'yelp'},{n:'Airbnb',i:'airbnb'},
  {n:'Uber',i:'uber'},{n:'Lyft',i:'lyft'},{n:'Stripe',i:'stripe'},
  {n:'Bitcoin',i:'bitcoin'},{n:'Ethereum',i:'ethereum'},
  {n:'Kickstarter',i:'kickstarter'},{n:'Jira',i:'jira'},{n:'Trello',i:'trello'},
  {n:'Atlassian',i:'atlassian'},{n:'Last.fm',i:'lastfm'},{n:'Bandcamp',i:'bandcamp'},
  {n:'Deezer',i:'deezer'},{n:'App Store',i:'app-store'},{n:'Google Play',i:'google-play'},
  {n:'رابط',i:'link'},{n:'بريد',i:'envelope'},{n:'موقع',i:'globe'},
  {n:'هاتف',i:'phone'},{n:'موضع',i:'location-dot'},{n:'مشاركة',i:'share-nodes'},
  {n:'متجر',i:'store'},{n:'حقيبة',i:'briefcase'},{n:'فيديو',i:'video'},
  {n:'صورة',i:'image'},{n:'موسيقى',i:'music'},{n:'نجمة',i:'star'},
  {n:'قلب',i:'heart'},{n:'كاميرا',i:'camera'},{n:'كود',i:'code'},
  {n:'لابتوب',i:'laptop'}
];

function getIcon(icon, iconSvg) {
  if (iconSvg && iconSvg.trim().startsWith('<')) return iconSvg;
  return socialIcons[icon?.toLowerCase()] || socialIcons.default;
}

/* ── Font family name per font ID ── */
function fontFamilyName(id) { return `fp-${id}`; }

function injectFontFaces(fonts) {
  const styleTag = document.getElementById('dynamic-font-faces');
  if (!styleTag) return;
  const rules = fonts.filter(f => f.fontFile).map(f => {
    const family = fontFamilyName(f.id);
    const fmt = f.fontFile.endsWith('.woff2') ? 'woff2' : f.fontFile.endsWith('.woff') ? 'woff'
              : f.fontFile.endsWith('.ttf') ? 'truetype' : 'opentype';
    return `@font-face { font-family: '${family}'; src: url('${f.fontFile}') format('${fmt}'); font-weight: 400 900; }`;
  }).join('\n');
  styleTag.textContent = rules;
}

/* ── SPLASH ── */
window.addEventListener('load', async () => {
  const params = new URLSearchParams(window.location.search);
  const previewSection = params.get('preview');
  if (previewSection) {
    document.getElementById('splash').style.display = 'none';
    if (previewSection === 'font-detail') {
      const fontId = params.get('fontId');
      await loadContent();
      if (fontId) openFontPage(Number(fontId));
    } else {
      loadContent();
      if (previewSection !== 'home') switchSection(previewSection);
    }
    return;
  }
  trackVisit();
  setTimeout(() => {
    const splash = document.getElementById('splash');
    splash.classList.add('slide-up');
    setTimeout(() => { splash.style.display = 'none'; }, 820);
  }, 2300);
});

function trackVisit() { fetch('/api/track-visit', { method: 'POST' }).catch(() => {}); }

/* ── SECTION SWITCHING ── */
function switchSection(id) {
  if (id === currentSection) return;
  currentSection = id;
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.drawer-item').forEach(b => b.classList.remove('active'));
  document.getElementById('sec-' + id)?.classList.add('active');
  document.querySelectorAll(`.drawer-item[data-section="${id}"]`).forEach(b => b.classList.add('active'));
  window.scrollTo(0, 0);
  closeDrawer();
}

/* ── DRAWER ── */
function openDrawer() {
  document.getElementById('drawer').classList.add('open');
  document.getElementById('drawer-overlay').classList.add('open');
}
function closeDrawer() {
  document.getElementById('drawer').classList.remove('open');
  document.getElementById('drawer-overlay').classList.remove('open');
}
document.getElementById('menu-toggle').addEventListener('click', openDrawer);
document.getElementById('drawer-close').addEventListener('click', closeDrawer);
document.getElementById('drawer-overlay').addEventListener('click', closeDrawer);
document.querySelectorAll('.drawer-item').forEach(btn => {
  btn.addEventListener('click', e => { e.preventDefault(); switchSection(btn.dataset.section); });
});

document.getElementById('topbar-logo').addEventListener('click', () => {
  if (token) openAdmin(); else openLoginModal();
});

/* ── LOAD CONTENT ── */
async function loadContent() {
  try {
    const res = await fetch('/api/content');
    contentData = await res.json();
    if (!contentData.workLinks) contentData.workLinks = [];
    injectFontFaces(contentData.fonts || []);
    renderSocial();
    renderWorkSocial();
    renderHomeFonts();
    initHomeSlider();
    if (token) renderAdminLists();
  } catch(e) { console.error(e); }
}

/* ── SOCIAL ── */
function renderSocial() {
  const grid = document.getElementById('social-grid');
  const active = (contentData.socialLinks || []).filter(l => l.url);
  if (!active.length) { grid.innerHTML = '<p class="links-empty">لم تُضف روابط بعد</p>'; return; }
  grid.innerHTML = active.map(l => `
    <a class="social-row-card" href="${l.url}" target="_blank" rel="noopener">
      <div class="src-icon">${getIcon(l.icon, l.iconSvg)}</div>
    </a>`).join('');
}

function renderWorkSocial() {
  const grid = document.getElementById('work-social-grid');
  const active = (contentData.workLinks || []).filter(l => l.url);
  if (!active.length) { grid.innerHTML = '<p class="links-empty">لم تُضف روابط بعد</p>'; return; }
  grid.innerHTML = active.map(l => `
    <a class="social-row-card" href="${l.url}" target="_blank" rel="noopener">
      <div class="src-icon">${getIcon(l.icon, l.iconSvg)}</div>
    </a>`).join('');
}

/* ── WEIGHT NAME MAPPING ── */
const weightNameMap = {
  '100':'Thin','200':'ExtraLight','300':'Light','400':'Regular',
  '500':'Medium','600':'SemiBold','700':'Bold','800':'ExtraBold','900':'Black'
};
function resolveWeightName(w) {
  const s = String(w).trim();
  return weightNameMap[s] || s;
}

/* ── FONT CARDS ── */
function buildFontCard(f) {
  const weights = (f.weights || []).map(resolveWeightName);
  const en = f.titleEn || '';
  const family = f.fontFile ? fontFamilyName(f.id) : 'Qahwa';
  const familyCSS = `'${family}', serif`;
  const priceBadge = f.isPaid
    ? '<span class="badge-paid">مدفوع</span>'
    : '<span class="badge-free">مجاني</span>';
  const weightsHtml = weights.length
    ? `<div class="font-card-weights">${weights.map(w => `<span class="weight-tag" style="font-family:${familyCSS}">${w}</span>`).join('')}</div>`
    : '';
  return `
    <div class="font-card" onclick="openFontPage(${f.id})">
      <div class="font-card-body">
        <div class="font-card-preview">
          <span class="font-card-ar" style="font-family:${familyCSS}">${f.title}</span>
          ${en ? `<span class="font-card-en" style="font-family:${familyCSS}">${en}</span>` : ''}
        </div>
      </div>
      <div class="font-card-footer">
        <div class="font-card-footer-left">
          ${priceBadge}
          ${weightsHtml}
        </div>
        <span class="font-card-arrow"><i class="fa-solid fa-arrow-left"></i></span>
      </div>
    </div>`;
}

function renderHomeFonts(filtered) {
  const grid = document.getElementById('home-fonts-grid');
  const empty = document.getElementById('home-fonts-empty');
  const items = filtered !== undefined ? filtered : (contentData.fonts || []);
  if (!grid) return;
  if (!items.length) {
    grid.innerHTML = '';
    if (empty) empty.classList.remove('hidden');
    return;
  }
  if (empty) empty.classList.add('hidden');
  grid.innerHTML = items.map(f => buildFontCard(f)).join('');
}

/* ── SEARCH ── */
function initSearch() {
  const input = document.getElementById('font-search');
  const clearBtn = document.getElementById('search-clear');
  const suggestionsEl = document.getElementById('search-suggestions');
  if (!input) return;

  input.addEventListener('input', () => {
    const q = input.value.trim().toLowerCase();
    clearBtn.classList.toggle('hidden', !q);

    if (!q) {
      renderHomeFonts();
      suggestionsEl.classList.add('hidden');
      return;
    }

    const fonts = contentData.fonts || [];
    const matches = fonts.filter(f =>
      f.title.toLowerCase().includes(q) ||
      (f.titleEn || '').toLowerCase().includes(q)
    );

    renderHomeFonts(matches);

    if (matches.length && matches.length < fonts.length) {
      suggestionsEl.innerHTML = matches.map(f => `
        <div class="suggestion-item" onclick="selectSuggestion(${f.id})">
          <span class="sug-ar">${f.title}</span>
          ${f.titleEn ? `<span class="sug-en">${f.titleEn}</span>` : ''}
        </div>`).join('');
      suggestionsEl.classList.remove('hidden');
    } else {
      suggestionsEl.classList.add('hidden');
    }
  });

  clearBtn.addEventListener('click', () => {
    input.value = '';
    clearBtn.classList.add('hidden');
    suggestionsEl.classList.add('hidden');
    renderHomeFonts();
    input.focus();
  });

  document.addEventListener('click', e => {
    if (!e.target.closest('.home-search-wrap')) suggestionsEl.classList.add('hidden');
  });
}

window.selectSuggestion = function(id) {
  const font = (contentData.fonts || []).find(f => f.id === id);
  if (!font) return;
  document.getElementById('font-search').value = font.title;
  document.getElementById('search-suggestions').classList.add('hidden');
  openFontPage(id);
};

/* ── HOME SLIDER ── */
let sliderIndex = 0;
let sliderTimer = null;
let sliderTotal = 0;

function initHomeSlider() {
  const fonts = contentData.fonts || [];
  const slides = [];
  fonts.forEach(f => {
    const images = f.images && f.images.length ? f.images : (f.image ? [f.image] : []);
    images.forEach(img => slides.push({ img, font: f }));
  });

  const wrap = document.getElementById('home-slider-wrap');
  if (!slides.length) { if (wrap) wrap.classList.add('hidden'); return; }
  if (wrap) wrap.classList.remove('hidden');

  const slider = document.getElementById('home-slider');
  const dots   = document.getElementById('home-slider-dots');
  const btnPrev = document.getElementById('slider-prev');
  const btnNext = document.getElementById('slider-next');
  if (!slider || !dots) return;

  sliderTotal = slides.length;
  const family = f => f.fontFile ? `'${fontFamilyName(f.id)}', serif` : 'var(--font-black), serif';

  slider.innerHTML = slides.map(s => `
    <div class="home-slide" onclick="openFontPage(${s.font.id})">
      <img src="${s.img}" alt="${s.font.title}" loading="lazy" />
      <div class="home-slide-label">
        <span class="home-slide-title" style="font-family:${family(s.font)}">${s.font.title}</span>
        ${s.font.titleEn ? `<span class="home-slide-en">${s.font.titleEn}</span>` : ''}
      </div>
    </div>`).join('');

  dots.innerHTML = slides.map((_, i) =>
    `<button class="slider-dot${i === 0 ? ' active' : ''}" onclick="goSlide(${i})"></button>`).join('');

  if (btnPrev) btnPrev.onclick = () => { sliderIndex=(sliderIndex-1+sliderTotal)%sliderTotal; updateSliderPos(); resetSliderTimer(); };
  if (btnNext) btnNext.onclick = () => { sliderIndex=(sliderIndex+1)%sliderTotal; updateSliderPos(); resetSliderTimer(); };

  sliderIndex = 0;
  updateSliderPos();
  resetSliderTimer();
}

function updateSliderPos() {
  const counter = document.getElementById('slider-counter');
  document.querySelectorAll('.home-slide').forEach((s, i) => {
    s.classList.remove('active', 'prev');
    if (i === sliderIndex) s.classList.add('active');
    else if (i === (sliderIndex-1+sliderTotal)%sliderTotal) s.classList.add('prev');
  });
  document.querySelectorAll('.slider-dot').forEach((d, i) => d.classList.toggle('active', i === sliderIndex));
  if (counter) counter.textContent = `${sliderIndex+1} / ${sliderTotal}`;
}

function resetSliderTimer() {
  clearInterval(sliderTimer);
  sliderTimer = setInterval(() => { sliderIndex=(sliderIndex+1)%sliderTotal; updateSliderPos(); }, 5000);
}

window.goSlide = function(i) { sliderIndex=i; updateSliderPos(); resetSliderTimer(); };

/* ── FONT DETAIL PAGE ── */
window.openFontPage = function(id) {
  const font = (contentData.fonts || []).find(f => f.id === id);
  if (!font) return;
  currentFontId = id;
  fetch(`/api/track-font/${id}`, { method: 'POST' }).catch(() => {});

  const family = font.fontFile ? fontFamilyName(font.id) : 'Qahwa';
  const familyCSS = `'${family}', serif`;

  // Apply font family to entire detail page
  const detailPage = document.querySelector('.font-detail-page');
  if (detailPage) detailPage.style.fontFamily = familyCSS;

  const titleEl = document.getElementById('fd-title-ar');
  titleEl.textContent = font.title;
  titleEl.style.fontFamily = familyCSS;

  const titleEnEl = document.getElementById('fd-title-en');
  titleEnEl.textContent = font.titleEn || '';
  titleEnEl.style.fontFamily = familyCSS;

  const descAr = document.getElementById('fd-desc-ar');
  const descEn = document.getElementById('fd-desc-en');
  const descsWrap = document.getElementById('fd-descriptions');
  descAr.textContent = font.descriptionAr || font.description || '';
  descAr.style.fontFamily = familyCSS;
  descEn.textContent = font.descriptionEn || '';
  descEn.style.fontFamily = familyCSS;
  descsWrap.style.display = (descAr.textContent || descEn.textContent) ? '' : 'none';

  const images = font.images && font.images.length ? font.images : (font.image ? [font.image] : []);
  document.getElementById('fd-images').innerHTML = images.map(src =>
    `<div class="fd-image-item"><img src="${src}" alt="${font.title}" loading="lazy" /></div>`).join('');

  const weights = (font.weights || []).map(resolveWeightName);
  const weightSection = document.getElementById('fd-weights-section');
  const weightText = document.getElementById('fd-weights-text');
  if (weights.length) {
    weightText.innerHTML = `<span class="fd-weights-label">الأوزان</span>
      <div class="fd-weights-tags">${weights.map(w => `<span class="fd-weight-tag" style="font-family:${familyCSS}">${w}</span>`).join('')}</div>`;
    weightText.style.fontFamily = familyCSS;
    weightSection.classList.remove('hidden');
  } else {
    weightSection.classList.add('hidden');
  }

  const pricingSection = document.getElementById('fd-pricing-section');
  const hasPricingInfo = font.isPaid !== undefined || font.license || (font.freeWeights && font.freeWeights.length) || (font.paidWeights && font.paidWeights.length);
  if (hasPricingInfo) {
    const priceBadge = document.getElementById('fd-price-badge');
    priceBadge.innerHTML = font.isPaid
      ? `<span class="fd-price-large paid" style="font-family:${familyCSS}">مدفوع</span>`
      : `<span class="fd-price-large free" style="font-family:${familyCSS}">مجاني</span>`;

    const licenseRow = document.getElementById('fd-license-row');
    if (font.license) {
      licenseRow.innerHTML = `<strong>الترخيص:</strong> ${font.license}`;
      licenseRow.style.fontFamily = familyCSS;
      licenseRow.classList.remove('hidden');
    } else { licenseRow.classList.add('hidden'); }

    const weightCats = document.getElementById('fd-weight-cats');
    let catsHTML = '';
    if (font.freeWeights && font.freeWeights.length)
      catsHTML += `<div class="fd-wcat"><div class="fd-wcat-label free">الأوزان المجانية</div>
        <div class="fd-wcat-items">${font.freeWeights.map(w=>`<span class="fd-wcat-tag" style="font-family:${familyCSS}">${w}</span>`).join('')}</div></div>`;
    if (font.paidWeights && font.paidWeights.length)
      catsHTML += `<div class="fd-wcat"><div class="fd-wcat-label paid">الأوزان المدفوعة</div>
        <div class="fd-wcat-items">${font.paidWeights.map(w=>`<span class="fd-wcat-tag" style="font-family:${familyCSS}">${w}</span>`).join('')}</div></div>`;
    weightCats.innerHTML = catsHTML;
    pricingSection.classList.remove('hidden');
  } else { pricingSection.classList.add('hidden'); }

  const downloadWrap = document.getElementById('fd-download-wrap');
  if (font.downloadUrl) {
    const btn = document.getElementById('fd-download-btn');
    btn.href = font.downloadUrl;
    btn.style.fontFamily = familyCSS;
    if (font.isPaid) {
      btn.innerHTML = '<i class="fa-solid fa-bag-shopping"></i> شراء الخط';
      btn.setAttribute('target', '_blank');
    } else {
      btn.innerHTML = '<i class="fa-solid fa-download"></i> تحميل الخط';
      btn.setAttribute('target', '_blank');
    }
    downloadWrap.classList.remove('hidden');
  } else { downloadWrap.classList.add('hidden'); }

  // Apply font family to back button
  const backBtn = document.getElementById('font-detail-back');
  if (backBtn) backBtn.style.fontFamily = familyCSS;

  switchSection('font-detail');
};

/* ── DOWNLOAD TRACKING ── */
document.getElementById('fd-download-btn').addEventListener('click', () => {
  if (currentFontId) fetch(`/api/track-download/${currentFontId}`, { method: 'POST' }).catch(() => {});
});

document.getElementById('font-detail-back').addEventListener('click', () => switchSection('home'));

/* ── PRICE TOGGLE BUTTONS ── */
function setPriceToggle(form, isPaid) {
  const hiddenId = form === 'add' ? 'add-is-paid' : 'edit-is-paid';
  document.getElementById(hiddenId).value = isPaid ? 'true' : 'false';
  document.querySelectorAll(`.pt-btn[data-form="${form}"]`).forEach(btn => {
    btn.classList.toggle('active', btn.dataset.val === String(isPaid));
  });
}
document.querySelectorAll('.pt-btn').forEach(btn => {
  btn.addEventListener('click', () => setPriceToggle(btn.dataset.form, btn.dataset.val === 'true'));
});

/* ── LOGIN ── */
function openLoginModal() { document.getElementById('login-modal').classList.remove('hidden'); }
document.getElementById('close-login').onclick = () => document.getElementById('login-modal').classList.add('hidden');
document.getElementById('login-modal').onclick = e => {
  if (e.target === document.getElementById('login-modal')) document.getElementById('login-modal').classList.add('hidden');
};
document.getElementById('login-form').onsubmit = async e => {
  e.preventDefault();
  const username = document.getElementById('username-input').value;
  const password = document.getElementById('password-input').value;
  const err = document.getElementById('login-error');
  err.classList.add('hidden');
  try {
    const res = await fetch('/api/login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({username,password}) });
    const data = await res.json();
    if (!res.ok) { err.textContent = data.error; err.classList.remove('hidden'); return; }
    token = data.token; localStorage.setItem('admin_token', token);
    document.getElementById('login-modal').classList.add('hidden');
    openAdmin();
  } catch { err.textContent = 'حدث خطأ، حاول مجدداً'; err.classList.remove('hidden'); }
};

/* ── ADMIN ── */
function openAdmin() {
  document.getElementById('admin-panel').classList.remove('hidden');
  renderSocialEditor(); renderWorkSocialEditor(); renderAdminLists();
}
function closeAdmin() { document.getElementById('admin-panel').classList.add('hidden'); }
document.getElementById('logout-btn').onclick = () => { token = null; localStorage.removeItem('admin_token'); closeAdmin(); };

document.querySelectorAll('.atab').forEach(btn => {
  btn.onclick = () => {
    document.querySelectorAll('.atab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.atab-content').forEach(t => t.classList.add('hidden'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.atab).classList.remove('hidden');
    if (btn.dataset.atab === 'stats-tab') loadStats();
  };
});

/* ── ICON PICKER ── */
function buildIconPickerHTML() {
  return `<div class="ip-search-wrap"><input class="ip-search" placeholder="ابحث..." oninput="filterIcons(this.value)" /></div>
    <div class="ip-grid">${iconLibrary.map(ic=>`
      <button type="button" class="ip-btn" title="${ic.n}" data-icon="${ic.i}" onclick="selectPickerIcon('${ic.i}')">
        ${socialIcons[ic.i]||'<i class="fa-solid fa-link"></i>'}
        <span class="ip-label">${ic.n}</span>
      </button>`).join('')}</div>`;
}

window.filterIcons = function(q) {
  const lq = q.toLowerCase();
  document.querySelectorAll('.ip-btn').forEach(b => {
    b.style.display = (!lq || b.title.toLowerCase().includes(lq) || b.dataset.icon.includes(lq)) ? '' : 'none';
  });
};

window.selectPickerIcon = function(icon) {
  if (!_pickerTarget) return;
  const row = _pickerTarget.closest('.social-editor-row');
  _pickerTarget.value = icon;
  const previewBtn = row.querySelector('.se-icon-preview');
  if (previewBtn) previewBtn.innerHTML = socialIcons[icon] || socialIcons.default;
  const popup = document.getElementById('icon-picker-popup');
  if (popup) popup.classList.add('hidden');
  _pickerTarget = null;
};

window.toggleIconPicker = function(btn) {
  const row = btn.closest('.social-editor-row');
  const hiddenInput = row.querySelector('.se-icon-val');
  const popup = document.getElementById('icon-picker-popup');
  if (!popup.classList.contains('hidden') && _pickerTarget === hiddenInput) {
    popup.classList.add('hidden'); _pickerTarget = null; return;
  }
  _pickerTarget = hiddenInput;
  const rect = btn.getBoundingClientRect();
  popup.style.top = (rect.bottom + window.scrollY + 6) + 'px';
  popup.style.left = Math.max(8, rect.left + window.scrollX - 100) + 'px';
  popup.classList.remove('hidden');
  popup.querySelector('.ip-search').value = '';
  filterIcons('');
};

function initIconPicker() {
  const popup = document.createElement('div');
  popup.id = 'icon-picker-popup';
  popup.className = 'icon-picker-popup hidden';
  popup.innerHTML = buildIconPickerHTML();
  document.body.appendChild(popup);
  document.addEventListener('click', e => {
    if (!e.target.closest('#icon-picker-popup') && !e.target.closest('.se-icon-btn')) {
      popup.classList.add('hidden'); _pickerTarget = null;
    }
  });
}

function seRow(l, i, type) {
  const iconHtml = socialIcons[l.icon?.toLowerCase()] || socialIcons.default;
  const removeCall = type === 'social' ? `removeSocial(${i})` : `removeWorkSocial(${i})`;
  return `<div class="social-editor-row" data-index="${i}">
    <button type="button" class="se-icon-btn" onclick="toggleIconPicker(this)">
      <span class="se-icon-preview">${iconHtml}</span>
      <i class="fa-solid fa-chevron-down se-caret"></i>
    </button>
    <input type="hidden" class="se-icon-val" value="${l.icon||'link'}" />
    <input type="url" class="se-url" value="${l.url||''}" placeholder="رابط الحساب..." />
    <input type="text" class="se-name" value="${l.platform||''}" placeholder="اسم المنصة" />
    <button class="btn-remove" onclick="${removeCall}"><i class="fa-solid fa-xmark"></i></button>
  </div>`;
}

/* ── SOCIAL EDITOR ── */
function renderSocialEditor() {
  document.getElementById('social-editor').innerHTML =
    (contentData.socialLinks || []).map((l,i) => seRow(l,i,'social')).join('');
}
window.removeSocial = i => { contentData.socialLinks.splice(i,1); renderSocialEditor(); };
document.getElementById('add-social-btn').onclick = () => {
  contentData.socialLinks = contentData.socialLinks || [];
  contentData.socialLinks.push({ id: Date.now(), platform:'منصة جديدة', url:'', icon:'link', iconSvg:'' });
  renderSocialEditor();
};
document.getElementById('save-social-btn').onclick = async () => {
  const rows = document.querySelectorAll('#social-editor .social-editor-row');
  const updated = [];
  rows.forEach((row,i) => {
    updated.push({
      id: contentData.socialLinks[i]?.id || Date.now()+i,
      url: row.querySelector('.se-url').value,
      platform: row.querySelector('.se-name').value,
      icon: row.querySelector('.se-icon-val').value,
      iconSvg: ''
    });
  });
  try {
    const res = await fetch('/api/social-links', { method:'PUT', headers:{'Content-Type':'application/json','Authorization':'Bearer '+token}, body:JSON.stringify(updated) });
    if (!res.ok) throw new Error();
    contentData.socialLinks = updated; renderSocial(); toast('تم الحفظ ✓');
  } catch { toast('فشل الحفظ', true); }
};

/* ── WORK SOCIAL EDITOR ── */
function renderWorkSocialEditor() {
  document.getElementById('work-social-editor').innerHTML =
    (contentData.workLinks || []).map((l,i) => seRow(l,i,'work')).join('');
}
window.removeWorkSocial = i => { contentData.workLinks.splice(i,1); renderWorkSocialEditor(); };
document.getElementById('add-work-social-btn').onclick = () => {
  contentData.workLinks = contentData.workLinks || [];
  contentData.workLinks.push({ id: Date.now(), platform:'منصة جديدة', url:'', icon:'link', iconSvg:'' });
  renderWorkSocialEditor();
};
document.getElementById('save-work-social-btn').onclick = async () => {
  const rows = document.querySelectorAll('#work-social-editor .social-editor-row');
  const updated = [];
  rows.forEach((row,i) => {
    updated.push({
      id: contentData.workLinks[i]?.id || Date.now()+i,
      url: row.querySelector('.se-url').value,
      platform: row.querySelector('.se-name').value,
      icon: row.querySelector('.se-icon-val').value,
      iconSvg: ''
    });
  });
  try {
    const res = await fetch('/api/work-links', { method:'PUT', headers:{'Content-Type':'application/json','Authorization':'Bearer '+token}, body:JSON.stringify(updated) });
    if (!res.ok) throw new Error();
    contentData.workLinks = updated; renderWorkSocial(); toast('تم الحفظ ✓');
  } catch { toast('فشل الحفظ', true); }
};

/* ── FONT FORM ── */
document.getElementById('font-form').onsubmit = async e => {
  e.preventDefault();
  const fd = new FormData(e.target);
  try {
    const res = await fetch('/api/fonts', { method:'POST', headers:{'Authorization':'Bearer '+token}, body:fd });
    if (!res.ok) throw new Error();
    const item = await res.json();
    contentData.fonts = contentData.fonts || [];
    contentData.fonts.push(item); e.target.reset();
    injectFontFaces(contentData.fonts);
    renderHomeFonts(); initHomeSlider(); renderAdminLists(); toast('تمت الإضافة ✓');
  } catch { toast('فشل الإضافة', true); }
};

/* ── ADMIN LISTS ── */
function renderAdminLists() {
  const fList = document.getElementById('admin-fonts-list');
  const fs = contentData.fonts || [];
  fList.innerHTML = fs.map(f => {
    const images = f.images && f.images.length ? f.images : (f.image ? [f.image] : []);
    const thumb = images[0] || null;
    const weightsStr = (f.weights && f.weights.length) ? f.weights.join(' · ') : '';
    return `
    <div class="admin-item">
      ${thumb ? `<img src="${thumb}"/>` : '<div style="width:64px;height:64px;background:var(--bg4);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:#fff;flex-shrink:0"><i class="fa-solid fa-font"></i></div>'}
      <div class="admin-item-info">
        <h4>${f.title}${f.titleEn ? ` · ${f.titleEn}` : ''}</h4>
        <p style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          ${f.isPaid ? '<span class="badge-paid">مدفوع</span>' : '<span class="badge-free">مجاني</span>'}
          ${weightsStr ? `<span style="color:var(--muted2);font-size:0.77rem">${weightsStr}</span>` : ''}
          ${f.fontFile ? '<span style="color:#4ade80;font-size:0.77rem">✓ ملف خط</span>' : '<span style="color:#f87171;font-size:0.77rem">⚠ لا يوجد ملف خط</span>'}
        </p>
      </div>
      <div style="display:flex;gap:7px;flex-shrink:0">
        <button class="btn-edit" onclick="openEditModal(${f.id})">تعديل</button>
        <button class="btn-del" onclick="delItem(${f.id})">حذف</button>
      </div>
    </div>`;
  }).join('') || '<p style="color:var(--muted2);padding:10px">لا توجد خطوط</p>';
}

window.delItem = async (id) => {
  if (!confirm('هل أنت متأكد من الحذف؟')) return;
  try {
    const res = await fetch(`/api/fonts/${id}`, { method:'DELETE', headers:{'Authorization':'Bearer '+token} });
    if (!res.ok) throw new Error();
    contentData.fonts = contentData.fonts.filter(f => f.id !== id);
    injectFontFaces(contentData.fonts);
    renderHomeFonts(); initHomeSlider(); renderAdminLists(); toast('تم الحذف ✓');
  } catch { toast('فشل الحذف', true); }
};

/* ── EDIT FONT MODAL ── */
window.openEditModal = function(id) {
  const f = (contentData.fonts || []).find(x => x.id === id);
  if (!f) return;
  document.getElementById('edit-font-id').value       = f.id;
  document.getElementById('edit-title').value          = f.title || '';
  document.getElementById('edit-title-en').value       = f.titleEn || '';
  document.getElementById('edit-desc-ar').value        = f.descriptionAr || f.description || '';
  document.getElementById('edit-desc-en').value        = f.descriptionEn || '';
  document.getElementById('edit-download-url').value   = f.downloadUrl || '';
  document.getElementById('edit-weights').value        = (f.weights || []).join(', ');
  document.getElementById('edit-license').value        = f.license || '';
  document.getElementById('edit-free-weights').value   = (f.freeWeights || []).join(', ');
  document.getElementById('edit-paid-weights').value   = (f.paidWeights || []).join(', ');
  setPriceToggle('edit', !!f.isPaid);
  const currentFile = document.getElementById('edit-font-file-current');
  currentFile.textContent = f.fontFile ? `الملف الحالي: ${f.fontFile.split('/').pop()}` : 'لا يوجد ملف خط — ارفع الملف لتفعيل المعاينة';
  currentFile.style.color = f.fontFile ? 'var(--muted2)' : '#f87171';
  document.getElementById('edit-font-modal').classList.remove('hidden');
};
document.getElementById('close-edit-modal').onclick = () => document.getElementById('edit-font-modal').classList.add('hidden');
document.getElementById('edit-font-modal').onclick = e => {
  if (e.target === document.getElementById('edit-font-modal')) document.getElementById('edit-font-modal').classList.add('hidden');
};
document.getElementById('edit-font-form').onsubmit = async e => {
  e.preventDefault();
  const id = document.getElementById('edit-font-id').value;
  const fd = new FormData(e.target);
  fd.delete('fontId');
  fd.set('weights', document.getElementById('edit-weights').value);
  try {
    const res = await fetch(`/api/fonts/${id}`, { method:'PUT', headers:{'Authorization':'Bearer '+token}, body:fd });
    if (!res.ok) throw new Error();
    const updated = await res.json();
    const idx = contentData.fonts.findIndex(f => f.id == id);
    if (idx !== -1) contentData.fonts[idx] = updated;
    injectFontFaces(contentData.fonts);
    renderHomeFonts(); initHomeSlider(); renderAdminLists();
    document.getElementById('edit-font-modal').classList.add('hidden');
    toast('تم الحفظ ✓');
  } catch { toast('فشل الحفظ', true); }
};

/* ── STATS ── */
async function loadStats() {
  const container = document.getElementById('stats-container');
  try {
    const res = await fetch('/api/stats', { headers: { 'Authorization': 'Bearer ' + token } });
    if (!res.ok) throw new Error();
    const stats = await res.json();
    document.getElementById('stat-total').textContent = stats.totalVisits.toLocaleString('ar');
    document.getElementById('stat-today').textContent = stats.todayVisits.toLocaleString('ar');
    const fontsList = document.getElementById('stats-fonts-list');
    if (!stats.fontViews || !stats.fontViews.length) {
      fontsList.innerHTML = '<p style="color:var(--muted2);padding:10px 0">لا توجد بيانات بعد</p>';
    } else {
      fontsList.innerHTML = stats.fontViews.map(f => `
        <div class="stats-font-row">
          <div>
            <div class="stats-font-name">${f.title}</div>
            ${f.en ? `<div class="stats-font-en">${f.en}</div>` : ''}
          </div>
          <div style="display:flex;gap:8px;align-items:center">
            <span class="stats-font-count"><i class="fa-solid fa-eye" style="font-size:0.75rem;opacity:0.5"></i> ${f.views.toLocaleString('ar')}</span>
            <span class="stats-font-count" style="background:rgba(74,222,128,0.1);color:#4ade80"><i class="fa-solid fa-download" style="font-size:0.75rem;opacity:0.7"></i> ${f.downloads.toLocaleString('ar')}</span>
          </div>
        </div>`).join('');
    }
  } catch {
    container.innerHTML = '<p style="color:#e74c3c;padding:20px 0">تعذّر تحميل الإحصائيات</p>';
  }
}

/* ── TOAST ── */
function toast(msg, isErr = false) {
  const el = document.createElement('div');
  el.textContent = msg;
  el.style.cssText = `position:fixed;bottom:28px;left:50%;transform:translateX(-50%);
    background:${isErr?'#c0392b':'#1a1a1a'};color:#fff;padding:11px 22px;
    border:1px solid ${isErr?'#e74c3c':'#333'};border-radius:8px;
    font-family:'Qahwa',sans-serif;font-weight:500;font-size:0.92rem;
    z-index:9999;box-shadow:0 4px 24px rgba(0,0,0,0.6);`;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2800);
}

/* ── INIT SEARCH + ICON PICKER ── */
initSearch();
initIconPicker();
